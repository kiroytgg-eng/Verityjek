package com.verity;

import com.verity.item.VerityBallItem;
import com.verity.item.VerityBoxItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public class VerityItems {
    public static final Item BOX = Registry.register(Registries.ITEM, VerityMod.id("verity_box"),
            new VerityBoxItem(new Item.Settings().maxCount(16)));

    public static final Item BALL = Registry.register(Registries.ITEM, VerityMod.id("verity_ball"),
            new VerityBallItem(new Item.Settings().maxCount(1)));

    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP, VerityMod.id("main"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(BALL))
                    .displayName(Text.translatable("itemGroup.verity.main"))
                    .entries((context, entries) -> {
                        entries.add(BOX);
                        entries.add(BALL);
                    })
                    .build());

    public static void register() {
    }
}
