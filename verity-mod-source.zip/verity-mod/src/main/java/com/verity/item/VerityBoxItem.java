package com.verity.item;

import com.verity.VerityEntities;
import com.verity.entity.VerityBoxEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class VerityBoxItem extends Item {
    public VerityBoxItem(Settings settings) {
        super(settings);
    }

    /** Click derecho: la caja aparece 3 bloques frente a ti, en el suelo. */
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient) {
            Vec3d f = flatLook(player);
            if (spawnBox(world, player, player.getX() + f.x * 3.0, player.getZ() + f.z * 3.0) && !player.isCreative()) {
                stack.decrement(1);
            }
        }
        return TypedActionResult.success(stack, world.isClient);
    }

    /** Direccion horizontal hacia donde mira el jugador (largo 1). */
    public static Vec3d flatLook(PlayerEntity player) {
        Vec3d look = player.getRotationVector();
        double len = Math.sqrt(look.x * look.x + look.z * look.z);
        if (len < 1.0E-4) return new Vec3d(0, 0, 1);
        return new Vec3d(look.x / len, 0, look.z / len);
    }

    /** Pone la caja de Verity en el suelo en (x, z), buscando el piso cerca de la altura del jugador. */
    public static boolean spawnBox(World world, PlayerEntity player, double x, double z) {
        double y = player.getY();
        int fy = MathHelper.floor(player.getY());
        for (int dy = 4; dy >= -6; dy--) {
            BlockPos bp = new BlockPos(MathHelper.floor(x), fy + dy, MathHelper.floor(z));
            var shape = world.getBlockState(bp).getCollisionShape(world, bp);
            if (!shape.isEmpty() && world.getBlockState(bp.up()).getCollisionShape(world, bp.up()).isEmpty()) {
                y = bp.getY() + shape.getMax(Direction.Axis.Y);
                break;
            }
        }
        VerityBoxEntity box = VerityEntities.BOX.create(world);
        if (box == null) return false;
        box.refreshPositionAndAngles(x, y, z, player.getYaw(), 0f);
        world.spawnEntity(box);
        return true;
    }

    /** La caja aparece al lado del jugador, a 5 bloques (a su derecha y un poquito al frente). */
    public static boolean spawnBoxBeside(World world, PlayerEntity player) {
        Vec3d f = flatLook(player);
        double rx = -f.z, rz = f.x; // derecha del jugador
        return spawnBox(world, player, player.getX() + rx * 5.0 + f.x * 1.5, player.getZ() + rz * 5.0 + f.z * 1.5);
    }
}
