package com.verity;

import com.verity.entity.VerityBallEntity;
import com.verity.item.VerityBoxItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;

public class VerityMod implements ModInitializer {
    public static final String MODID = "verity";

    public static Identifier id(String path) {
        return new Identifier(MODID, path);
    }

    private static final String WELCOME_TAG = "verity_welcome";
    private final Map<UUID, Integer> pendingWelcome = new HashMap<>();

    @Override
    public void onInitialize() {
        VerityEntities.register();
        VerityItems.register();
        VerityCommands.register();
        VerityGifts.registerReceivers();

        // Al entrar al mundo (la primera vez) aparece la caja a 5 bloques a tu lado.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.getPlayer();
            if (!p.getCommandTags().contains(WELCOME_TAG)) pendingWelcome.put(p.getUuid(), 60);
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (pendingWelcome.isEmpty()) return;
            Iterator<Map.Entry<UUID, Integer>> it = pendingWelcome.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<UUID, Integer> en = it.next();
                int left = en.getValue() - 1;
                if (left > 0) {
                    en.setValue(left);
                    continue;
                }
                it.remove();
                ServerPlayerEntity p = server.getPlayerManager().getPlayer(en.getKey());
                if (p != null && VerityBoxItem.spawnBoxBeside(p.getWorld(), p)) p.addCommandTag(WELCOME_TAG);
            }
        });

        // Si sueltas el item Verity™ (tecla Q), en vez de quedar como item sale la bola 3D, cae y rebota en el piso.
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof ItemEntity item && item.getStack().isOf(VerityItems.BALL)) {
                world.getServer().execute(() -> {
                    if (item.isRemoved()) return;
                    VerityBallEntity ball = VerityEntities.BALL.create(world);
                    if (ball == null) return;
                    ball.refreshPositionAndAngles(item.getX(), item.getY(), item.getZ(), 0f, 0f);
                    PlayerEntity near = world.getClosestPlayer(item, 8.0);
                    ball.setOwnerUuid(near != null ? near.getUuid() : null);
                    ball.configureAsPlaced();
                    world.spawnEntity(ball);
                    item.discard();
                });
            }
        });
    }
}
