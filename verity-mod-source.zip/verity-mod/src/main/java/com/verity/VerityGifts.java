package com.verity;

import com.verity.entity.VerityBallEntity;
import com.verity.item.VerityBoxItem;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

/** Lo que Verity puede regalar (solo cosas basicas: nada de hierro, diamante, netherite, obsidiana...) y "ven detras de mi". */
public final class VerityGifts {
    /** Lista blanca. Todo lo que no este aqui, el servidor lo rechaza. */
    public static final Set<String> ALLOWED = new TreeSet<>(Arrays.asList(
            "stick", "oak_planks", "spruce_planks", "birch_planks", "oak_log", "spruce_log", "birch_log",
            "cobblestone", "stone", "dirt", "sand", "gravel", "glass", "white_wool", "oak_sapling",
            "torch", "coal", "charcoal", "flint", "string", "feather", "leather", "bone", "bone_meal", "clay_ball",
            "bread", "apple", "carrot", "potato", "baked_potato", "cooked_chicken", "cooked_porkchop", "cooked_mutton",
            "cooked_cod", "melon_slice", "sweet_berries", "cookie", "sugar", "egg", "cocoa_beans",
            "wheat", "wheat_seeds", "beetroot_seeds", "pumpkin_seeds", "melon_seeds",
            "crafting_table", "furnace", "chest", "barrel", "ladder", "oak_door", "oak_fence",
            "wooden_sword", "wooden_pickaxe", "wooden_axe", "wooden_shovel", "wooden_hoe",
            "stone_sword", "stone_pickaxe", "stone_axe", "stone_shovel", "stone_hoe",
            "bow", "arrow", "fishing_rod"));

    private static final Set<String> FOOD = new TreeSet<>(Arrays.asList(
            "bread", "apple", "carrot", "potato", "baked_potato", "cooked_chicken", "cooked_porkchop", "cooked_mutton",
            "cooked_cod", "melon_slice", "sweet_berries", "cookie"));

    private static final Map<UUID, Integer> LAST_GIVE = new HashMap<>();
    private static final int COOLDOWN_TICKS = 100; // 5 s entre regalos

    private VerityGifts() {
    }

    public static String allowedList() {
        return String.join(", ", ALLOWED);
    }

    private static int cap(String id) {
        if (id.endsWith("_sword") || id.endsWith("_pickaxe") || id.endsWith("_axe") || id.endsWith("_shovel")
                || id.endsWith("_hoe") || id.equals("bow") || id.equals("fishing_rod")) return 1;
        if (id.equals("arrow")) return 16;
        if (FOOD.contains(id)) return 8;
        if (id.endsWith("_log")) return 16;
        return 32;
    }

    public static void registerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(VerityNet.GIVE, (server, player, handler, buf, sender) -> {
            String raw = buf.readString(64);
            int count = buf.readInt();
            server.execute(() -> give(player, raw, count));
        });
        ServerPlayNetworking.registerGlobalReceiver(VerityNet.COME, (server, player, handler, buf, sender) ->
                server.execute(() -> comeBehind(player)));
    }

    private static void give(ServerPlayerEntity player, String raw, int count) {
        String id = raw.toLowerCase().replace("minecraft:", "").trim();
        if (!ALLOWED.contains(id)) {
            player.sendMessage(Text.literal("[Verity] Eso no puedo dártelo.").formatted(Formatting.RED), false);
            return;
        }
        int now = player.getServer().getTicks();
        Integer last = LAST_GIVE.get(player.getUuid());
        if (last != null && now - last < COOLDOWN_TICKS) {
            player.sendMessage(Text.literal("[Verity] Espera un poquito para otro regalo.").formatted(Formatting.RED), false);
            return;
        }
        Identifier ident = Identifier.tryParse("minecraft:" + id);
        if (ident == null || !Registries.ITEM.containsId(ident)) return;
        Item item = Registries.ITEM.get(ident);
        int n = Math.max(1, Math.min(count, cap(id)));
        LAST_GIVE.put(player.getUuid(), now);
        ItemStack stack = new ItemStack(item, n);
        player.getInventory().offerOrDrop(stack);
        player.getWorld().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.PLAYERS, 0.6f, 1.2f);
        player.sendMessage(Text.literal("[Verity] Te di " + n + " x ").append(item.getName()).formatted(Formatting.YELLOW), false);
    }

    /** Verity se coloca justo detras del jugador (y se queda quieta ahi). */
    private static void comeBehind(ServerPlayerEntity player) {
        ServerWorld w = player.getServerWorld();
        UUID me = player.getUuid();
        List<VerityBallEntity> balls = w.getEntitiesByType(VerityEntities.BALL, player.getBoundingBox().expand(128.0),
                b -> b.getBallState() != VerityBallEntity.STATE_HELD && (b.getOwnerUuid() == null || b.getOwnerUuid().equals(me)));
        VerityBallEntity best = null;
        double bd = Double.MAX_VALUE;
        for (VerityBallEntity b : balls) {
            double d = b.squaredDistanceTo(player);
            if (d < bd) {
                bd = d;
                best = b;
            }
        }
        if (best == null) return;
        Vec3d f = VerityBoxItem.flatLook((PlayerEntity) player);
        best.refreshPositionAndAngles(player.getX() - f.x * 1.8, player.getY() + 0.4, player.getZ() - f.z * 1.8, 0f, 0f);
        best.setVelocity(Vec3d.ZERO);
        best.configureAsPlaced();
        w.playSound(null, best.getX(), best.getY(), best.getZ(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.NEUTRAL, 0.4f, 1.8f);
    }
}
