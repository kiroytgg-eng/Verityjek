package com.verity.client;

import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Verity habla: escribe en el chat (en amarillo) y a la misma vez reproduce la voz de Fish Audio.
 * El audio se pide como WAV y se reproduce con el OpenAL del propio Minecraft (funciona tambien en Pojav/Android).
 */
public final class VerityVoice {
    private static final ExecutorService POOL = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "Verity-Voice");
        t.setDaemon(true);
        return t;
    });

    private static volatile boolean speaking;
    private static int fallbackTicks;
    private static int alSource;
    private static int alBuffer;

    private VerityVoice() {
    }

    /** True mientras Verity esta hablando (lo lee el renderer para estirar la bola y poner la cara de hablar). */
    public static boolean isSpeaking() {
        return speaking;
    }

    private static boolean fishWarned;

    /** Verity dice algo: chat + voz. Llamar desde el hilo del cliente. */
    public static void say(String text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        VerityConfig cfg = VerityConfig.get();
        String clean = cleanForSpeech(text);
        boolean useFish = cfg.fishEnabled && cfg.fishKey != null && !cfg.fishKey.isBlank();
        boolean useGemini = cfg.geminiVoiceFallback && cfg.geminiKey != null && !cfg.geminiKey.isBlank();
        if ((!useFish && !useGemini) || clean.isEmpty()) {
            showChat(text);
            startFallback(text);
            return;
        }
        final String fishKey = useFish ? cfg.fishKey.trim() : "";
        final String fishModel = cfg.fishModel == null || cfg.fishModel.isBlank() ? "s2-pro" : cfg.fishModel.trim();
        final String fishVoice = cfg.fishVoiceId == null ? "" : cfg.fishVoiceId.trim();
        POOL.execute(() -> {
            Wav wav = null;
            String fishError = null, geminiError = null;
            if (useFish) {
                try {
                    wav = Wav.parse(fishTts(fishKey, fishModel, fishVoice, clean));
                } catch (Exception e) {
                    fishError = Http.shorten(String.valueOf(e.getMessage()), 160);
                }
            }
            if (wav == null && useGemini) {
                try {
                    wav = geminiTts(cfg, clean);
                } catch (Exception e) {
                    geminiError = Http.shorten(String.valueOf(e.getMessage()), 160);
                }
            }
            final Wav result = wav;
            final String fe = fishError, ge = geminiError;
            mc.execute(() -> {
                showChat(text);
                if (result != null) {
                    if (fe != null && !fishWarned) {
                        fishWarned = true;
                        mc.inGameHud.getChatHud().addMessage(Text.literal("[Verity] Fish Audio falló (" + fe
                                + "). Uso la voz de Gemini.").formatted(Formatting.RED));
                    }
                    play(result, text);
                } else {
                    if (fe != null) mc.inGameHud.getChatHud().addMessage(Text.literal("[Verity] Fish Audio: " + fe).formatted(Formatting.RED));
                    if (ge != null) mc.inGameHud.getChatHud().addMessage(Text.literal("[Verity] Voz Gemini: " + ge).formatted(Formatting.RED));
                    startFallback(text);
                }
            });
        });
    }

    /** Voz gratis de Gemini (TTS). Devuelve PCM de 16 bits, 24000 Hz, mono. */
    private static Wav geminiTts(VerityConfig cfg, String text) throws IOException {
        JsonObject root = new JsonObject();
        com.google.gson.JsonArray contents = new com.google.gson.JsonArray();
        JsonObject c = new JsonObject();
        com.google.gson.JsonArray parts = new com.google.gson.JsonArray();
        JsonObject p = new JsonObject();
        p.addProperty("text", text);
        parts.add(p);
        c.add("parts", parts);
        contents.add(c);
        root.add("contents", contents);
        JsonObject gen = new JsonObject();
        com.google.gson.JsonArray mods = new com.google.gson.JsonArray();
        mods.add("AUDIO");
        gen.add("responseModalities", mods);
        JsonObject speech = new JsonObject(), vc = new JsonObject(), pre = new JsonObject();
        pre.addProperty("voiceName", cfg.geminiVoiceName == null || cfg.geminiVoiceName.isBlank() ? "Kore" : cfg.geminiVoiceName.trim());
        vc.add("prebuiltVoiceConfig", pre);
        speech.add("voiceConfig", vc);
        gen.add("speechConfig", speech);
        root.add("generationConfig", gen);

        String model = cfg.geminiTtsModel == null || cfg.geminiTtsModel.isBlank() ? "gemini-3.1-flash-tts-preview" : cfg.geminiTtsModel.trim();
        Map<String, String> headers = new HashMap<>();
        headers.put("x-goog-api-key", cfg.geminiKey.trim());
        Http.Response r = Http.postJson("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent",
                headers, root.toString(), 60000);
        if (r.code >= 400) throw new IOException("HTTP " + r.code + " " + Http.shorten(r.text(), 160));
        try {
            JsonObject resp = com.google.gson.JsonParser.parseString(r.text()).getAsJsonObject();
            for (com.google.gson.JsonElement part : resp.getAsJsonArray("candidates").get(0).getAsJsonObject()
                    .getAsJsonObject("content").getAsJsonArray("parts")) {
                JsonObject po = part.getAsJsonObject();
                if (po.has("inlineData")) {
                    JsonObject id = po.getAsJsonObject("inlineData");
                    int rate = 24000;
                    if (id.has("mimeType")) {
                        java.util.regex.Matcher m = java.util.regex.Pattern.compile("rate=(\\d+)").matcher(id.get("mimeType").getAsString());
                        if (m.find()) rate = Integer.parseInt(m.group(1));
                    }
                    byte[] pcm = java.util.Base64.getDecoder().decode(id.get("data").getAsString());
                    pcm = java.util.Arrays.copyOf(pcm, pcm.length - pcm.length % 2);
                    return new Wav(pcm, 1, rate);
                }
            }
        } catch (RuntimeException e) {
            throw new IOException("respuesta de audio no válida: " + Http.shorten(r.text(), 120));
        }
        throw new IOException("Gemini no devolvió audio: " + Http.shorten(r.text(), 120));
    }

    /** Llamar una vez por tick del cliente. */
    public static void tick() {
        if (alSource != 0) {
            boolean playing;
            try {
                playing = AL10.alGetSourcei(alSource, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING;
            } catch (Throwable t) {
                playing = false;
            }
            if (!playing) {
                releaseAudio();
                speaking = false;
            }
        } else if (fallbackTicks > 0) {
            fallbackTicks--;
            if (fallbackTicks == 0) speaking = false;
        }
    }

    public static void stop() {
        releaseAudio();
        fallbackTicks = 0;
        speaking = false;
    }

    // ------------------------------------------------------------------ chat

    private static void showChat(String text) {
        MutableText line = Text.literal("<Verity> " + text).formatted(Formatting.YELLOW);
        MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(line);
    }

    private static void startFallback(String text) {
        releaseAudio();
        fallbackTicks = Math.max(40, Math.min(260, (int) (text.length() * 2.4)));
        speaking = true;
    }

    // ---------------------------------------------------------------- Fish

    private static byte[] fishTts(String key, String model, String voice, String text) throws IOException {
        JsonObject body = new JsonObject();
        body.addProperty("text", text);
        if (!voice.isEmpty()) body.addProperty("reference_id", voice);
        body.addProperty("format", "wav");
        body.addProperty("sample_rate", 44100);
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + key);
        headers.put("model", model);
        Http.Response r = Http.postJson("https://api.fish.audio/v1/tts", headers, body.toString(), 60000);
        if (r.code >= 400) throw new IOException("HTTP " + r.code + " " + Http.shorten(r.text(), 180));
        return r.body;
    }

    private static String cleanForSpeech(String s) {
        return s.replaceAll("https?://\\S+", "").replaceAll("[*_`#]", "").replaceAll("\\s+", " ").trim();
    }

    // ---------------------------------------------------------------- audio

    private static void play(Wav wav, String text) {
        releaseAudio();
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            ByteBuffer bb = BufferUtils.createByteBuffer(wav.pcm.length);
            bb.put(wav.pcm).flip();
            int buffer = AL10.alGenBuffers();
            AL10.alBufferData(buffer, wav.channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, bb, wav.sampleRate);
            int source = AL10.alGenSources();
            float gain = (float) VerityConfig.get().volume
                    * mc.options.getSoundVolume(SoundCategory.MASTER)
                    * mc.options.getSoundVolume(SoundCategory.VOICE);
            AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
            AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
            AL10.alSource3f(source, AL10.AL_POSITION, 0f, 0f, 0f);
            AL10.alSourcef(source, AL10.AL_GAIN, Math.max(0f, Math.min(1f, gain)));
            AL10.alSourcePlay(source);
            int err = AL10.alGetError();
            if (err != AL10.AL_NO_ERROR) {
                AL10.alDeleteSources(source);
                AL10.alDeleteBuffers(buffer);
                throw new IllegalStateException("OpenAL error " + err);
            }
            alSource = source;
            alBuffer = buffer;
            fallbackTicks = 0;
            speaking = true;
        } catch (Throwable t) {
            alSource = 0;
            alBuffer = 0;
            MinecraftClient.getInstance().inGameHud.getChatHud().addMessage(
                    Text.literal("[Verity] No pude reproducir el audio: " + t).formatted(Formatting.RED));
            startFallback(text);
        }
    }

    private static void releaseAudio() {
        try {
            if (alSource != 0) {
                AL10.alSourceStop(alSource);
                AL10.alDeleteSources(alSource);
            }
            if (alBuffer != 0) AL10.alDeleteBuffers(alBuffer);
        } catch (Throwable ignored) {
        }
        alSource = 0;
        alBuffer = 0;
    }

    /** Un WAV PCM de 16 bits ya desempaquetado. */
    static final class Wav {
        final byte[] pcm;
        final int channels;
        final int sampleRate;

        Wav(byte[] pcm, int channels, int sampleRate) {
            this.pcm = pcm;
            this.channels = channels;
            this.sampleRate = sampleRate;
        }

        static Wav parse(byte[] d) throws IOException {
            if (d.length < 44 || d[0] != 'R' || d[1] != 'I' || d[2] != 'F' || d[3] != 'F') {
                throw new IOException("la respuesta no es WAV: " + Http.shorten(new String(d, 0, Math.min(d.length, 160), StandardCharsets.UTF_8), 120));
            }
            ByteBuffer bb = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
            int pos = 12;
            int channels = 1, rate = 44100, bits = 16;
            int dataStart = -1, dataLen = 0;
            while (pos + 8 <= d.length) {
                String id = new String(d, pos, 4, StandardCharsets.US_ASCII);
                long size = bb.getInt(pos + 4) & 0xFFFFFFFFL;
                if (id.equals("fmt ")) {
                    channels = bb.getShort(pos + 10);
                    rate = bb.getInt(pos + 12);
                    bits = bb.getShort(pos + 22);
                } else if (id.equals("data")) {
                    dataStart = pos + 8;
                    dataLen = (int) Math.min(size, (long) d.length - dataStart);
                    break;
                }
                if (size > d.length) break;
                pos += 8 + (int) size + (int) (size & 1);
            }
            if (dataStart < 0) throw new IOException("WAV sin datos de audio");
            if (bits != 16) throw new IOException("WAV de " + bits + " bits no soportado");
            if (channels < 1 || channels > 2) throw new IOException("WAV con " + channels + " canales no soportado");
            dataLen -= dataLen % (2 * channels);
            byte[] pcm = new byte[dataLen];
            System.arraycopy(d, dataStart, pcm, 0, dataLen);
            return new Wav(pcm, channels, rate);
        }
    }
}
