package com.verity.client;

import com.verity.VerityEntities;
import com.verity.VerityItems;
import com.verity.client.render.VerityBallRenderer;
import com.verity.client.render.VerityBoxRenderer;
import com.verity.entity.VerityBallEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import com.verity.client.render.ObjModel;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;

public class VerityClient implements ClientModInitializer {
    private static KeyBinding configKey;
    private static KeyBinding talkKey;
    private static long lastEventMs;

    @Override
    public void onInitializeClient() {
        VerityConfig.load();
        EntityRendererRegistry.register(VerityEntities.BOX, VerityBoxRenderer::new);
        EntityRendererRegistry.register(VerityEntities.BALL, VerityBallRenderer::new);

        // El item Verity™ se dibuja como el modelo 3D (en la mano, el inventario y en el suelo)
        BuiltinItemRendererRegistry.INSTANCE.register(VerityItems.BALL, (stack, mode, m, vcp, light, overlay) -> {
            m.push();
            m.translate(0.5f, 0.5f, 0.5f);
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f));
            if (mode == net.minecraft.client.render.model.json.ModelTransformationMode.GUI) {
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(14f)); // la cara te mira de frente
            }
            m.scale(1.1f, 1.1f, 1.1f);
            m.translate(0f, -0.404f, 0f);
            VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(VerityTextures.get("fakesmile")));
            ObjModel.get().render(m.peek(), vc, light, 1f, 1f, 1f, 1f);
            m.pop();
        });

        VerityBallEntity.CLIENT_TALK = b -> openTalk();
        VerityBallEntity.CLIENT_GREET = VerityClient::greet;

        configKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.verity.config",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, "key.categories.verity"));
        talkKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.verity.talk",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.verity"));

        // Ajustes sin depender de Mod Menu: comando /verityconfig, tecla J, o boton en la ventana de hablar
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("verityconfig").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new VerityConfigScreen(null)));
                    return 1;
                })));

        ClientTickEvents.END_CLIENT_TICK.register(VerityClient::tick);
        ClientSendMessageEvents.ALLOW_CHAT.register(VerityClient::onChat);
    }

    // ---------------------------------------------------------------- helpers

    /** Verity te escucha si esta cerca (la bola) O si la llevas en el inventario como Verity™. */
    public static boolean hasVerity() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return false;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isOf(VerityItems.BALL)) return true;
        }
        return findBall() != null;
    }

    public static VerityBallEntity findBall() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return null;
        VerityBallEntity best = null;
        double bestD = 48 * 48;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof VerityBallEntity b && b.getBallState() != VerityBallEntity.STATE_HELD) {
                if (b.getOwnerUuid() != null && !b.getOwnerUuid().equals(mc.player.getUuid())) continue;
                double d = b.squaredDistanceTo(mc.player);
                if (d < bestD) {
                    bestD = d;
                    best = b;
                }
            }
        }
        return best;
    }

    private static void openTalk() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.setScreen(new VerityTalkScreen());
    }

    private static void greet(VerityBallEntity ball) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (ball.getOwnerUuid() != null && !ball.getOwnerUuid().equals(mc.player.getUuid())) return;
        VerityVoice.say(VerityConfig.get().greeting);
    }

    // ------------------------------------------------------------------ tick

    private static void tick(MinecraftClient mc) {
        VerityVoice.tick();
        if (mc.player == null || mc.world == null) return;

        while (configKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new VerityConfigScreen(null));
        }
        while (talkKey.wasPressed()) {
            if (mc.currentScreen == null && hasVerity()) openTalk();
        }

        // Verity celosa / obsesionada reacciona cuando alguien se te acerca
        if (mc.world.getTime() % 20 != 0) return;
        VerityPersonality p = VerityConfig.get().personalityEnum();
        if (p != VerityPersonality.CELOSA && p != VerityPersonality.OBSESIONADA) return;
        if (VerityVoice.isSpeaking() || VerityBrain.isBusy()) return;
        if (System.currentTimeMillis() - lastEventMs < 45000) return;
        if (!hasVerity()) return;

        ClientPlayerEntity me = mc.player;
        Box area = me.getBoundingBox().expand(5.0);
        List<PlayerEntity> players = mc.world.getEntitiesByClass(PlayerEntity.class, area, o -> o != me && !o.isSpectator());
        String note = null;
        if (!players.isEmpty()) {
            note = "El jugador " + players.get(0).getName().getString() + " se acaba de acercar mucho a tu jugador.";
        } else {
            List<VillagerEntity> v = mc.world.getEntitiesByClass(VillagerEntity.class, area.contract(2.0), o -> true);
            if (!v.isEmpty()) note = "Un aldeano se acaba de acercar mucho a tu jugador.";
        }
        if (note == null) return;
        lastEventMs = System.currentTimeMillis();
        VerityConfig cfg = VerityConfig.get();
        boolean hasKey = "groq".equalsIgnoreCase(cfg.provider) ? !cfg.groqKey.isBlank() : !cfg.geminiKey.isBlank();
        if (hasKey) {
            VerityBrain.askEvent(note);
        } else {
            VerityVoice.say(p == VerityPersonality.CELOSA
                    ? "¿Y esa persona quién es? ¿Por qué se te acerca tanto? Hmph."
                    : "Aléjate de él. Solo me necesitas a mí, ¿verdad? Solo a mí.");
        }
    }

    // ------------------------------------------------------------------ chat

    /** Hablar por chat: "verity ..." (siempre) o cualquier mensaje si la bola esta a menos de 16 bloques. */
    private static boolean onChat(String message) {
        String m = message.trim();
        if (m.isEmpty() || m.startsWith("/")) return true;
        String low = m.toLowerCase(Locale.ROOT);
        boolean prefixed = low.startsWith("verity") && (low.length() == 6 || !Character.isLetterOrDigit(low.charAt(6)));
        String rest = null;
        if (prefixed) {
            if (!hasVerity()) return true;
            rest = m.substring(6).replaceFirst("^[\\s,:;!¡¿?.\\-]+", "");
            if (rest.isEmpty()) rest = "Hola";
        } else if (VerityConfig.get().answerAllChat) {
            VerityBallEntity b = findBall();
            MinecraftClient mc = MinecraftClient.getInstance();
            if (b != null && mc.player != null && b.squaredDistanceTo(mc.player) < 16 * 16) rest = m;
        }
        if (rest != null) VerityBrain.ask(rest);
        return true;
    }
}
