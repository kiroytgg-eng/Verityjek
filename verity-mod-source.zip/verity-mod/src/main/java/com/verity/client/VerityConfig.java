package com.verity.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Ajustes de Verity. Se guardan en .minecraft/config/verity.json */
public class VerityConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static VerityConfig instance;

    // IA
    public String provider = "gemini";                 // "gemini" o "groq"
    public String geminiKey = "";
    public String geminiModel = "gemini-flash-latest";
    public String groqKey = "";
    public String groqModel = "llama-3.3-70b-versatile";

    // Voz (Fish Audio)
    public boolean fishEnabled = true;
    public String fishKey = "";
    public String fishModel = "s2-pro";                // va en el header "model"
    public String fishVoiceId = "";                    // reference_id: el ID de la voz que quieres

    // Voz de respaldo gratis con tu key de Gemini (se usa si Fish falla o no tiene saldo)
    public boolean geminiVoiceFallback = true;
    public String geminiTtsModel = "gemini-3.1-flash-tts-preview";
    public String geminiVoiceName = "Kore";

    // Verity
    public String personality = "NORMAL";
    public double hue = 60.0;                          // 60 = amarillo original
    public double saturation = 1.0;
    public double size = 1.0;
    public double volume = 1.0;
    public boolean answerAllChat = true;               // con la bola cerca (16 bloques) contesta todo lo que escribas en el chat
    public String greeting = "¡Holaa! Soy Verity. Tu amiga asistente personal, pregúntame lo que sea, yo lo sé todo.";

    public VerityPersonality personalityEnum() {
        return VerityPersonality.byName(personality);
    }

    public static VerityConfig get() {
        if (instance == null) load();
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("verity.json");
    }

    public static void load() {
        Path p = path();
        try {
            if (Files.exists(p)) {
                String json = Files.readString(p, StandardCharsets.UTF_8);
                VerityConfig c = GSON.fromJson(json, VerityConfig.class);
                if (c != null) {
                    instance = c;
                    return;
                }
            }
        } catch (Exception e) {
            System.err.println("[Verity] No pude leer verity.json: " + e);
        }
        instance = new VerityConfig();
        save();
    }

    public static void save() {
        try {
            Path p = path();
            Files.createDirectories(p.getParent());
            Files.writeString(p, GSON.toJson(get()), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.err.println("[Verity] No pude guardar verity.json: " + e);
        }
    }
}
