package com.verity.client.render;

import com.verity.client.VerityConfig;
import com.verity.client.VerityTextures;
import com.verity.client.VerityVoice;
import com.verity.entity.VerityBallEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

public class VerityBallRenderer extends EntityRenderer<VerityBallEntity> {
    public VerityBallRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.28f;
    }

    @Override
    public Identifier getTexture(VerityBallEntity entity) {
        return VerityTextures.base("fakesmile");
    }

    @Override
    public void render(VerityBallEntity e, float yaw, float tickDelta, MatrixStack m, VertexConsumerProvider vcp, int light) {
        float t = e.age + tickDelta;

        // siempre mira hacia ti
        double ex = MathHelper.lerp(tickDelta, e.prevX, e.getX());
        double ez = MathHelper.lerp(tickDelta, e.prevZ, e.getZ());
        Vec3d cam = this.dispatcher.camera.getPos();
        float faceYaw = (float) Math.toDegrees(Math.atan2(-(cam.x - ex), -(cam.z - ez)));

        boolean speaking = VerityVoice.isSpeaking();
        int state = e.getBallState();
        float sx = 1f, sy = 1f;

        // sale de la caja chiquita y crece
        float emerge = 1f;
        if (state == VerityBallEntity.STATE_HELD) {
            float k = MathHelper.clamp(t / 16f, 0f, 1f);
            emerge = 0.35f + 0.65f * (1f - (1f - k) * (1f - k));
        }

        // golpe contra el piso: se aplasta y vuelve
        float since = (e.age - e.clientImpactAge) + tickDelta;
        boolean recentImpact = e.clientImpactAge >= 0 && since < 16f;
        if (recentImpact) {
            float s = (float) (Math.exp(-0.32 * since) * Math.cos(0.85 * since));
            sy -= 0.38f * s;
            sx += 0.22f * s;
        }

        // al caer se estira
        double fall = e.prevY - e.getY();
        if (state == VerityBallEntity.STATE_FALLING && fall > 0.05) {
            float st = (float) Math.min(0.2, fall * 0.35);
            sy += st;
            sx -= st * 0.5f;
        }

        // hablando: se estira rítmicamente; quieta: respira
        String face = "fakesmile";
        if (speaking) {
            float w = 0.5f + 0.5f * MathHelper.sin(t * 0.85f);
            sy *= 1.08f + 0.12f * w;
            sx *= 0.97f - 0.04f * w;
            boolean open = MathHelper.sin(t * 1.15f + 1.7f * MathHelper.sin(t * 0.37f)) > -0.3f;
            face = open ? "open" : "closed";
        } else {
            sy *= 1f + 0.012f * MathHelper.sin(t * 0.12f);
            if (recentImpact) face = "hurt";
        }

        float size = (float) VerityConfig.get().size * emerge;
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(VerityTextures.get(face)));

        m.push();
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(faceYaw));
        m.scale(size * sx, size * sy, size * sx);
        m.translate(0f, -0.029f, 0f);
        ObjModel.get().render(m.peek(), vc, light, 1f, 1f, 1f, 1f);
        m.pop();

        super.render(e, yaw, tickDelta, m, vcp, light);
    }
}
