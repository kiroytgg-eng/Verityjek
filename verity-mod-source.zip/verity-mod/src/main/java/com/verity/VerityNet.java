package com.verity;

import net.minecraft.util.Identifier;

public final class VerityNet {
    /** Cliente -> servidor: "dame este item" (String id, int cantidad). */
    public static final Identifier GIVE = VerityMod.id("give");
    /** Cliente -> servidor: "Verity, ven detras de mi". */
    public static final Identifier COME = VerityMod.id("come");

    private VerityNet() {
    }
}
